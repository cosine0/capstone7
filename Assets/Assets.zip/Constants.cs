﻿static class Constants
{
    public const float SmoothFactorCompass = 0.125f;
    public const float SmoothThresholdCompass = 45.0f;
}